# Global Superstore – Week 3
**Advanced Data Analysis, Statistical Validation & Feature Engineering**  
AnalystLab Africa Data Science Internship Programme

**Analyst:** Ozoeze Wilord Ugonna

---

## Project Continuity

This Week 3 work continues the Global Superstore project from Weeks 1 and 2.

| Week | Focus | Status |
|------|--------|--------|
| 1 | Business understanding & initial EDA | Completed |
| 2 | Data cleaning & preparation | Completed |
| **3** | **Advanced EDA, statistical tests, feature engineering & evaluation** | **This submission** |
| 4 | Machine learning model development | Next |

The cleaned dataset from Week 2 is reused. Full re-cleaning is not repeated.

---

## Business Problem

How can Global Superstore improve profitability by understanding which products, segments, regions, shipping choices, and discount practices drive or destroy profit?

**Primary outcome of interest:** Profit and loss-making behaviour.

---

## Week 3 Objectives Completed

- [x] Project Continuity Summary  
- [x] Advanced Exploratory Data Analysis (≥ 12 meaningful visuals, new insights)  
- [x] At least 4 statistical hypothesis tests with full documentation  
- [x] At least 3 engineered features with business justification  
- [x] Feature evaluation and selection decisions  
- [x] Refined modelling dataset exported  
- [x] Business Insights & Recommendations Report  

---

## Statistical Tests Performed

1. **Kruskal-Wallis** – Profit across Categories  
2. **Mann-Whitney U** – Profit for Discounted vs Non-discounted orders  
3. **Chi-Square** – Association between Segment and Order Priority  
4. **Spearman correlations** – Sales, Discount, Shipping Cost vs Profit  

Each test includes H₀, H₁, method justification, statistic, p-value, decision, and business implication.

---

## Engineered Features

| Feature | Description |
|---------|-------------|
| `Profit_Margin` | Profit / Sales |
| `Is_Loss_Making` | 1 if Profit < 0, else 0 |
| `Discount_Impact` | Sales × Discount |
| `Shipping_Efficiency` | Shipping Cost / Sales |
| `Days_to_Ship` | Ship Date − Order Date (days) |

---

## Repository Structure (Week 3 addition)

```text
├── data/
│   ├── cleaned/                          # from Week 2
│   └── modelling/
│       └── global_superstore_modelling_dataset.csv
├── notebooks/
│   └── week3_advanced_analysis.ipynb
├── reports/
│   ├── 01_Project_Continuity_Summary.md
│   ├── 02_Statistical_Analysis_Summary.md
│   ├── 03_Feature_Engineering_Documentation.md
│   ├── 04_Feature_Evaluation_Selection_Summary.md
│   └── 05_Business_Insights_Recommendations_Report.md
├── README.md
└── requirements.txt
```

---

## How to Reproduce

```bash
pip install -r requirements.txt
jupyter notebook notebooks/week3_advanced_analysis.ipynb
```

---

## Key Tools

- Python, Pandas, NumPy  
- Matplotlib, Seaborn  
- SciPy (statistical tests)  
- Jupyter Notebook  
- GitHub  

---

## Assessment Alignment

| Criterion | Weight |
|-----------|--------|
| Advanced Exploratory Data Analysis | 20% |
| Statistical Analysis & Interpretation | 25% |
| Feature Engineering | 15% |
| Feature Evaluation & Selection | 15% |
| Business Insights & Recommendations | 15% |
| Documentation & Professionalism | 10% |

---

## Next Step (Week 4)

Use `global_superstore_modelling_dataset.csv` to build and evaluate machine learning models that predict loss-making orders or profit, and translate model results into final business recommendations.
